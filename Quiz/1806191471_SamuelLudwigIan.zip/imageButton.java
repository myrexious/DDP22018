
public class imageButton{

    public imageButton(String path){
        // ImageView img = new ImageView(path);
        // img.setPickOnBounds(true);                  // allows click on transparent areas
        // img.setOnMouseClicked((MouseEvent e) -> {
        //     System.out.println("Clicked!");         // change functionality
        //     }
        //);
    }
}