public class Board {

	private final int SIZE = 3;
	private char[][] papan;

	public Board(char[][] papan) {
		this.papan = papan;
	}

	public void check() {
		// TO DO

	}

	// Optional, boleh digunakan / tidak digunakan
	// return banyaknya karakter c pada papan
	public int count(char c) {
		int ret = 0;
		for(int i = 0; i < SIZE; i++)
			for(int j = 0; j < SIZE; j++)
				if(papan[i][j] == c) ret++;
		return ret;
	}

	// Optional, boleh digunakan / tidak digunakan
	// return true jika sudah ditemukan pemenang di papan
	public boolean isWinnerFound() {
		boolean ret = false;
		for(int i = 0; i < SIZE; i++) if(papan[i][0] != '.')
			ret |= papan[i][0] == papan[i][1] && papan[i][1] == papan[i][2];
		for(int i = 0; i < SIZE; i++) if(papan[0][i] != '.')
			ret |= papan[0][i] == papan[1][i] && papan[1][i] == papan[2][i];
		if(papan[1][1] != '.') {
			ret |= papan[1][1] == papan[0][0] && papan[1][1] == papan[2][2];
			ret |= papan[1][1] == papan[0][2] && papan[1][1] == papan[2][0];
		}
		return ret;
	}
}