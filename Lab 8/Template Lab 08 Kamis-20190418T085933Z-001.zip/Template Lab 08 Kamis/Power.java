public interface Power {
    // TODO tambahkan method yang diperlukan
}