public class LaserEye {
    // TODO tambahkan method yang diperlukan
}