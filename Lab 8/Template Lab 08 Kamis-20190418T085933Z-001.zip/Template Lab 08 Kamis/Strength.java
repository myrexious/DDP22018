public class Strength {
    // TODO tambahkan method yang diperlukan
}