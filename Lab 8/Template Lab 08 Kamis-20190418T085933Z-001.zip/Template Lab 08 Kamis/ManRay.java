public class ManRay {
    
    public ManRay(String name, int powerLevel) {
        // TODO initiate class sesuai parent class
        addPower(new LaserEye());
        addPower(new Strength());
    }

    // TODO tambahkan method-method lain yang diperlukan
}