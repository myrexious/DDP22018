import java.lang.Comparable;

public abstract class SuperHero implements Comparable<SuperHero>{
    // TODO tambahkan atribut-atribut yang diperlukan

    public SuperHero(String name, int powerLevel) {
        // TODO implementasikan constructor SuperHero
    }

    public void showPowers() {
        System.out.println(".....HEED ME.....");
        System.out.println("FOR MY NAAAAAAAME IS " + getName().toUpperCase());
        System.out.println("TIME TO SHOW YOU MY POWERS");
        // TODO tunjukkan kekuatan SuperHero
    }

    // TODO tambahkan method-method lain yang diperlukan

    @Override
    public int compareTo(SuperHero o) {
        // TODO override method ini.
        // HINT: https://docs.oracle.com/javase/10/docs/api/java/lang/Comparable.html#compareTo-T-
    }
}