public class FlyingDutchMan {
    
    public FlyingDutchMan(String name, int powerLevel) {
        // TODO initiate class sesuai parent class
        addPower(new Flying());
        addPower(new LaserEye());
    }

    // TODO tambahkan method-method lain yang diperlukan
}