public class Flying {
    // TODO tambahkan method yang diperlukan
}