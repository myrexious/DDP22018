public class DirtyBubble {
    
    public DirtyBubble(String name, int powerLevel) {
        // TODO initiate class sesuai parent class
        addPower(new Strength());
        addPower(new Flying());
    }

    // TODO tambahkan method-method lain yang diperlukan
}