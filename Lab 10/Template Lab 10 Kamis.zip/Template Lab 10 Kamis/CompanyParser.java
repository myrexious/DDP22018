import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

/**
 * Class CompanyParser.
 *
 * This class contains the function to parse the CSV file into a Company object with all the employees.
 */
public class CompanyParser {
    
    private static final String COMMA_DELIMITER = ",";

    /**
     * Method to parse CSV file into a Menu object.
     * The CSV format accepted by this function is:
     * emp_name,work_hour,job_role,stats
     *
     * @param filename (String) CSV input file name;
     * @return Company object with all the employees within the given file.
     * @throws IOException
     */
    public static Company parseCompany(String filename) throws IOException {
        /**
         * TODO implement this method.
         * Create a Company object.
         * Read the file content with BufferedReader and FileReader (see material section for hints).
         * For each line read except the first line, 
         * create an appropriate object (AssemblerProgrammer, UIUXDesigner, or WebDeveloper) from the given info.
         * Then, add the object to the company object's list of employees. HINT: use addEmployee() method.
         */
    }
}
