public class Status {

	// TODO tambahkan attribute-attribute yang diperlukan
	// TODO tambahkan method-method yang diperlukan
}
