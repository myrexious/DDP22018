import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class Admin extends Pengguna {

	private List<Chat> chatList;

	public Admin(long nomorKTP, String namaLengkap,
	             String email, LocalDate tanggalLahir,
	             String nomorTelepon) {
		super(nomorKTP, namaLengkap, email, tanggalLahir, nomorTelepon);
		this.chatList = new ArrayList<>();
	}

	// TODO tambahkan method-method yang diperlukan
}
