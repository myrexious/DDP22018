public class Barang {

	private Item item;
	private String warna;
	private String urlFoto;
	private String kondisi;
	private int lamaPenggunaan;
	private Anggota penyewa;
	private InfoBarangLevel infoBarangLevel;

	public Barang(Item item, String warna,
	              String urlFoto, String kondisi,
	              int lamaPenggunaan) {
		this.item = item;
		this.warna = warna;
		this.urlFoto = urlFoto;
		this.kondisi = kondisi;
		this.lamaPenggunaan = lamaPenggunaan;
	}
}
