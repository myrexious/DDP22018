public class LevelKeanggotaan {

	// Tambahkan attribute-attribute yang diperlukan 

	public LevelKeanggotaan(String namaLevel, long minimumPoin, String deskripsi) {
		this.namaLevel = namaLevel;
		this.minimumPoin = minimumPoin;
		this.deskripsi = deskripsi;
	}
	
	// TODO tambahkan method-method yang diperlukan
}
