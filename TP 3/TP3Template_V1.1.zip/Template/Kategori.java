import java.util.ArrayList;
import java.util.List;

public class Kategori {

	private String nama;
	private int level;
	private Kategori superKategori;
	private List<Kategori> subKategoriList;

	// TODO tambahkan method-method yang diperlukan
}
