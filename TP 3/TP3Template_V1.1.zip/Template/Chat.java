import java.time.LocalDateTime;

public class Chat {

	private String pesan;
	private LocalDateTime dateTime;
	private Anggota anggota;
	private Admin admin;

	// TODO tambahkan method-method yang diperlukan
}
