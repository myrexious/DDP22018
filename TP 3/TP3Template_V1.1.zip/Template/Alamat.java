public class Alamat {

	private Anggota pemilik;
	private String namaAlamat;
	private String jalan;
	private long nomor;
	private String kota;
	private int kodePos;

	// TODO tambahkan method-method yang diperlukan
}
