import java.time.LocalDateTime;

public class Pemesanan implements Orderable {

	// TODO tambahkan attribute-attribute yang diperlukan

	private int id;
	private LocalDateTime dateTimePesanan;

	public Pemesanan(int id, LocalDateTime dateTimePesanan,
	                 int kuantitasBarang, long hargaSewa,
	                 long ongkos, Anggota pemesan,
	                 Status status) {
		this.id = id;
		this.dateTimePesanan = dateTimePesanan;
		this.kuantitasBarang = kuantitasBarang;
		this.hargaSewa = hargaSewa;
		this.ongkos = ongkos;
		this.pemesan = pemesan;
		this.status = status;
	}

	// TODO tambahkan method-method yang diperlukan
}
