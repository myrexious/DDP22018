public class InfoBarangLevel {

	private Barang barang;
	private LevelKeanggotaan level;
	private long hargaSewa;
	private long porsiLoyalti;
	private int ongkos; // *REVISED*

	// TODO tambahkan method-method yang diperlukan
}
