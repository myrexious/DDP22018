import java.util.ArrayList;
import java.util.List;

public class Item {

	// TODO tambahkan attribute-attribute lain yang diperlukan 

	private String nama;
	private String deskripsi;
	private int usiaDari;

	public Item(String nama, String deskripsi,
	            int usiaDari, int usiaSampai,
	            String bahan) {
		this.nama = nama;
		this.deskripsi = deskripsi;
		this.usiaDari = usiaDari;
		this.usiaSampai = usiaSampai;
		this.bahan = bahan;
		this.barangList = new ArrayList<>();
	}

	// TODO tambahkan method-method yang diperlukan
}
