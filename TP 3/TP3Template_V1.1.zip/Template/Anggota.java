public class Anggota extends Pengguna {


	// TODO tambahkan attribute-attribute yang diperlukan 
	
	public Anggota(long nomorKTP, String namaLengkap,
	               String email, LocalDate tanggalLahir,
	               String nomorTelepon, long poin,
	               LevelKeanggotaan levelKeanggotaan) {
		super(nomorKTP, namaLengkap, email, tanggalLahir, nomorTelepon);
		this.poin = poin;
		this.levelKeanggotaan = levelKeanggotaan;
		this.chatList = new ArrayList<>();
		this.alamatList = new ArrayList<>();
		this.pemesananList = new ArrayList<>();
	}

	// TODO tambahkan method-method yang diperlukan
}
